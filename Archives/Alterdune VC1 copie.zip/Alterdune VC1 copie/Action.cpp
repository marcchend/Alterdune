#include "Action.h"

std::vector<Action> Action::cat;

void Action::initCat() {
    cat = buildCat();
}

const Action& Action::getByI(const std::string& id) {
    static Action dummy("", "", 0);
    return dummy;
}

const std::vector<Action>& Action::getCat() {
    return cat;
}

std::vector<Action> buildCat() {
    std::vector<Action> c = {
        Action("JOKE", "blague", 20),
        Action("COMPLIMENT", "compliment", 25),
        Action("DISCUSS", "discuss", 15),
        Action("OBSERVE", "observe", 10),
        Action("PET", "pet", 30),
        Action("DANCE", "dance", 20),
        Action("OFFER_SNACK", "snack", 35),
        Action("REASON", "reason", 15),
        Action("INSULT", "insult", -20),
        Action("THREATEN", "threaten", -15)
    };
    return c;
}

const Action* findA(const std::vector<Action>& c, const std::string& id) {
    for (int i = 0; i < (int)c.size(); i++) {
        if (c[i].getI() == id) {
            return &c[i];
        }
    }
    return nullptr;
}
