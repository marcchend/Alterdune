#pragma once
#include <string>
#include <vector>

class Action {
private:
    std::string i; // id
    std::string t; // texte
    int mi; // mercyImpact
    static std::vector<Action> cat;

public:
    Action(std::string i, std::string t, int mi) : i(i), t(t), mi(mi) {}

    std::string getI() const { return i; }
    std::string getT() const { return t; }
    int getMi() const { return mi; }

    static void initCat();
    static const Action& getByI(const std::string& id);
    static const std::vector<Action>& getCat();
};

std::vector<Action> buildCat();
const Action* findA(const std::vector<Action>& cat, const std::string& id);
//
// On utilise un pointeur ici car :
//   - Si on retournait par valeur, on ne pourrait pas signaler "pas trouvé"
//   - nullptr est la convention C++ pour "rien trouvé"
// ===========================================================
const Action* findAction(const std::vector<Action>& catalogue, const std::string& id);
