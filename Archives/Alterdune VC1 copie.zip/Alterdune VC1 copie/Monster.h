#pragma once
#include "Entity.h"
#include "Action.h"
#include <vector>
#include <string>

enum Cat {
    N, M, B
};

class Monster : public Entity {
private:
    Cat c; // category
    int m; // mercy
    int mg; // mercyGoal
    bool wk; // wasKilled
    std::vector<std::string> a; // actIds

public:
    Monster(std::string n, int h, Cat cat, int mg, std::vector<std::string> a);

    Cat getC() const;
    int getM() const;
    int getMg() const;
    bool getWk() const;
    const std::vector<std::string>& getA() const;

    void setWk(bool v);

    void applyA(const Action& act);
    bool canMerc() const;
    int att(Entity& cible);
    std::string catStr() const;
    void display() const;
};
