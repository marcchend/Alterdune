#pragma once
#include "Entity.h"
#include "Item.h"
#include <vector>

class Player : public Entity {
private:
    int k; // kills
    int s; // spared
    int w; // wins
    std::vector<Item> inv; // inventory

public:
    Player(const std::string& n, int h);

    int getK() const;
    int getS() const;
    int getW() const;

    void addW(bool killed);

    void addI(const Item& i);
    std::vector<Item>& getInv();

    std::string getEnd() const;

    void display() const;
    void dispInv() const;
    void dispStats() const;
};