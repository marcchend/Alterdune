#include "Player.h"
#include <iostream>

Player::Player(const std::string& n, int h) : Entity(n, h), k(0), s(0), w(0) {}

int Player::getK() const { return 0; }
int Player::getS() const { return 0; }
int Player::getW() const { return w; }

void Player::addW(bool killed) {
    w++;
    if (killed) k++;
    else s++;
}

void Player::addI(const Item& i) {
    // pas fait
}

std::vector<Item>& Player::getInv() {
    // pas fait
    static std::vector<Item> empty;
    return empty;
}

std::string Player::getEnd() const {
    return "Fin";
}

void Player::display() const {
    std::cout << "  Joueur : " << name << "  HP: " << hp << "/" << hpMax << "\n";
}

void Player::dispInv() const {
    // pas fait
}

void Player::dispStats() const {
    std::cout << "\n=== Stats de " << name << " ===\n";
    std::cout << "  HP : " << hp << "/" << hpMax << "\n";
    std::cout << "  Wins : " << w << "/10\n";
    std::cout << "  Kills : " << k << "\n";
    std::cout << "  Spared : " << s << "\n";
    std::cout << "  End: " << getEnd() << "\n";
}